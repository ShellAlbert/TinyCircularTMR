//TMR chip sample frequency: 100KHz.
//Leading head byte: 0x55.
//AD7988-5 data width: 16-bits.
//Temperature: 8-bits.
//Total data bandwidth: (8+16+8)*100KHz=3.2Mbps.

//The UART band rate is 4Mbps,
//for a single byte transfer, there are start bit(1)+data bits(8)+stop bit(1)=10-bits.
//for the valid bandwidth is 4Mbps/100kHz=40bits.
//40-bits-(start+stop)*4=32-bits.

//We are using the 100% UART capacity.
//Must use 2x16 FIFO to reduce latency!!!!

module PoF_TMR_Top(

    //PCB Onboard oscillator 12MHz.
	input wire iClk_12MHz,
    input wire iRst_N,
	
    //Data Upload and Command Download.
    output wire oData_TxD,
    input wire iCmd_RxD,

    //AD7988 SPI-Compatible Interface.
	output wire oSPI_SDI,
	output wire oSPI_CNV,
	output wire oSPI_SCK,
	input wire iSPI_SDO, 

    //capture FPS(Frame Per Second).
    output reg oCap_FPS,
    output reg oTx_FPS,

    //TMP117 I2C Interface.
    output wire oTMP117_SCL,
    inout wire ioTMP117_SDA,
    input wire iTMP117_ALERT,

    //Debug LED*3.
	output wire oLED0, //Sample AD7988 and write data into FIFO.
    output wire oLED1, //UART Tx Indicator.
    output wire oLED2 //Read Temperature Sensor Indicator.
)/* synthesis RGB_TO_GPIO = "oLED0, oLED1" */;


//HSOSC
//High-frequency oscillator.
//Generates 48-MHz nominal clock, +/- 10 percent, with user-programmable divider. 
//Can drive global clock network or fabric routing.
//Input Ports
//CLKHFPU :Power up the oscillator.
//CLKHFEN :Enable the clock output. 
//CLKHF :Oscillator output
//Parameters
//CLKHF_DIV
//Clock divider selection:
//0'b00 = 48 MHz
//0'b01 = 24 MHz
//0'b10 = 12 MHz
//0'b11 = 6 MHz
wire clk_48MHz;
//By default, the outputs are routed to global clock network. 
//To route to local fabric, see the examples in the Appendix: Design Entry section.
HSOSC #(.CLKHF_DIV("0b00")) //48 MHz
my_HSOSC(
    .CLKHFPU(1'b1), 
    .CLKHFEN(1'b1), 
    .CLKHF(clk_48MHz)
)/* synthesis ROUTE_THROUGH_FABRIC= 0 */; //the value can be either 0 or 1

///////////////////////////////////////////////////////////////////
//We are not allowed to use PLL output, because it's exclusive with Pin-35. ADQ[7].
//if PLL use internal clock source, Pin-35 can be used as output.
//PLL: 48MHz->66MHz.
//WARNING!!!!!
//If I configured PLL outputs 70MHz, it doesn't work correctly.
//Then I slowed down to 66MHz, it starts to work.
//66MHz is not reliable, down to 48MHz.

//ERROR <67201318> - 
//When PLL.OUTCORE or PLL.OUTGLOBAL is used, the input IO at site 'PR13B' can only drive PLL.REFERENCECLK due to architecture constraint. 
//When PLL is utilized in the design, the I/O site 'PR13B' can only be used exclusively as a PLL clock input. 
//If PLL uses an internal clock, the I/O site 'PR13B' can be used as an output.
wire rst_short_n;
wire clk_48MHz_Global;
wire clk_48MHz_Fabric;
ZPLL ic_pll(
	//.ref_clk_i(clk_48MHz),  //On-board 48MHz.
	.ref_clk_i(iClk_12MHz), //External on board oscillator.
	.rst_n_i(1'b1), 
	.lock_o(rst_short_n), 
	.outcore_o(clk_48MHz_Fabric), 
	.outglobal_o(clk_48MHz_Global)
);

//extend rst_n to longer cycles.
reg rst_n;
reg [31:0] cntRst;
always @(posedge clk_48MHz_Global or negedge rst_short_n) 
if(!rst_short_n) begin rst_n<=0; cntRst<=0; end
else begin 
    cntRst<=(cntRst==32'hFFFFF0)?(cntRst):(cntRst+1);
    rst_n<=(cntRst==32'hFFFFF0)?(1):(0);
end


//sample data at 100KHz from AD7988.
/////////////////////////////////////////////////
//AD7988-1. Maximum Throughput Rate:100KHz.

/* the actual signal TMR is 50Hz */
/* we use 200 times to sample it, then Fs=50Hz*200=10kHz. */
//localparam TICK_MAX=4800; //48MHz/4800=10KHz.  //10kHz/50Hz=200.
localparam TICK_MAX=4800; //48MHz/2400=20KHz.   //20kHz/50Hz=400.

reg [15:0] cnt_100KHz;
always @(posedge clk_48MHz_Global or negedge rst_n) 
if(!rst_n) begin cnt_100KHz<=0; end
else begin 
    cnt_100KHz<=(cnt_100KHz==TICK_MAX-1)?(0):(cnt_100KHz+1); 
end
//single pulse to trigger capture.
wire capPulse;
assign capPulse=(cnt_100KHz==TICK_MAX-1)?(1):(0);
/////////////////////////////////////////////////////////////////////////
reg adc_en;
wire adc_valid;
wire [15:0] adc_data;
ZAD7988_Controller u1_ad7988(
	//common signals.
	.iClk(clk_48MHz_Global), //input clock.
	.iRstN(rst_n),
	.iEn(adc_en),

	//AD7988 SPI-Compatible Interface.
	.oSDI(oSPI_SDI),
	.oCNV(oSPI_CNV),
	.oSCK(oSPI_SCK),
	.iSDO(iSPI_SDO), 

	//acquire data output interface.
	.oData(adc_data),
	.oDataValid(adc_valid)
);
/////////////////////////////////////////////////
/* Operate ADC at a fixed frequency. */
reg [2:0] fsmADC;
reg [15:0] captured_data;
reg [31:0] LED_ADC_Working;
always @(posedge clk_48MHz_Global or negedge rst_n) 
if(!rst_n) begin fsmADC<=0; oCap_FPS<=0; LED_ADC_Working<=0; end
else begin
    case(fsmADC)
    0:  /* waiting for trigger signal */
        begin fsmADC<=(capPulse)?(fsmADC+1):(fsmADC); end
    1: /* enable ADC, after done, then disable it. */
        if(adc_valid) begin adc_en<=0; captured_data<=adc_data; fsmADC<=fsmADC+1; end
        else begin adc_en<=1; end
    2: /* additional clock period */
        begin 
            LED_ADC_Working<=(LED_ADC_Working==32'd1000)?(0):(LED_ADC_Working+1);
            oCap_FPS<=~oCap_FPS;
            fsmADC<=0; 
        end
    endcase
end
assign oLED0=(LED_ADC_Working>32'd400)?(1):(0);

//////////////////////////////////////////////////////////////////////////
reg [7:0] temp_Latest; //the latest temperature.
//////////////////////////////////////////////////////////////////////
/* Since the temperature changes slowly, acquires it every 1 second. */
reg TMP117_En;
wire TMP117_DataValid;
reg [1:0] TMP117_Cmd;
reg [7:0] TMP117_RegAddr;
reg [15:0] TMP117_RegData;
wire [15:0] TMP117_RdData;
reg [7:0] Temp_Result={8'h00};
reg [7:0] Config_Reg={8'h01}; //default value = 0x0220.
reg [7:0] THigh_Limit={8'h02};
reg [7:0] TLow_Limit={8'h03};
reg [7:0] Temp_Offset={8'h07};
reg [7:0] Device_ID={8'h0F};  //default value = 0x0117.
ZTMP117_Controller  myTMP117(
	.iClk(clk_48MHz_Global), //input clock.
	.iRstN(rst_n),
	.iEn(TMP117_En),

    //00: Read Device_ID regiter.
    //01: Read Temp_Result register.
    .iCommand(TMP117_Cmd), 
    .iRegAddr(TMP117_RegAddr),
    .iRegData(TMP117_RegData),

    //I2C Interface.
    .oSCL(oTMP117_SCL),
    .ioSDA(ioTMP117_SDA),

	//acquisition data output interface.
	.oRdData(TMP117_RdData),
	.oDataValid(TMP117_DataValid)
);
//driven by finite state machine.
reg [7:0] fsmTemp; 
reg [31:0] cnt_delay;
reg LED_Temp_Working;
//UART Protocol Format:
//55 High-Byte Low-Byte Temperature-Byte.
//0.0078125=2^(-7)
//if MSB is 1, negative.
//expand 1 bit for symbol.
reg unsigned [15:0] SensorData; 
reg symbol_bit;
reg [3:0] reg_iterator;
always @(posedge clk_48MHz_Global or negedge rst_n) 
if(!rst_n) begin 
    fsmTemp<=0; cnt_delay<=0; TMP117_En<=0; temp_Latest<=0; LED_Temp_Working<=0; reg_iterator<=0; 
end
else begin
    case(fsmTemp)
    0: //Temperature changes slow, read data every 1 second.
        //48MHz/1Hz=48_000_000
        if(cnt_delay==32'd48_000_000-1) begin cnt_delay<=0; fsmTemp<=fsmTemp+1; end
        else begin cnt_delay<=cnt_delay+1; end
    1: //Read Temperature.
        if(TMP117_DataValid) begin 
            TMP117_En<=0; 
            //only update when reads Temp_Result register.
            //SensorData<=(reg_iterator==5)?(TMP117_RdData):(SensorData);
            SensorData<=TMP117_RdData/*16'h8000*/;
            reg_iterator<=(reg_iterator==5)?(0):(reg_iterator+1);
            fsmTemp<=fsmTemp+1; 
        end
        else begin 
            TMP117_En<=1; TMP117_Cmd<=2'b00; 
            // case(reg_iterator)
            // 0: begin TMP117_RegAddr<=Device_ID; end
            // 1: begin TMP117_RegAddr<=Config_Reg; end
            // 2: begin TMP117_RegAddr<=THigh_Limit; end
            // 3: begin TMP117_RegAddr<=TLow_Limit; end
            // 4: begin TMP117_RegAddr<=Temp_Offset; end
            // 5: begin TMP117_RegAddr<=Temp_Result; end
            // default: begin TMP117_RegAddr<=Temp_Result; end
            // endcase
            TMP117_RegAddr<=Temp_Result; 
        end
    // 2: //1.convert BuMa to Yuan.
    //     begin
    //         SensorData<=(SensorData[15])?(~SensorData+1):(SensorData);
    //         symbol_bit<=(SensorData[15])?(1):(0);
    //         LED_Temp_Working<=~LED_Temp_Working; 
    //         fsmTemp<=fsmTemp+1; 
    //     end
    // 3:  //2.do multiplication to get the real temperature.
    //     //multiply 0.0078125 , 2^(-7)=1/128=0.0078125, right shift 7 bits.
    //     begin SensorData<=SensorData>>7; fsmTemp<=fsmTemp+1; end
    // 4: //3.convert YuanMa to BuMa.
    //     begin SensorData<=(symbol_bit)?(~SensorData+1):(SensorData); fsmTemp<=fsmTemp+1; end
    // 5: //update the latest temperature. //handling -0 problem individually.
    //     begin temp_Latest<=(symbol_bit & SensorData[6:0]=7'd0)?(0):{symbol_bit,SensorData[6:0]}; fsmTemp<=0; end
        2: //no need to convert between BuMa and YuanMa.
            //shifting right 7-bits means eliminate [0~6].
            //special handling -0: [14,13,12,11,10,9,8,7],[15] is symbol bit.
            //[15]+[13,12,11,10,9,8,7], eliminate [14]. range shrinks from +/-256 to +/-128.
            begin 
                temp_Latest<=(SensorData[15] & SensorData[14:7]==8'd0)?(0):{SensorData[15],SensorData[13:7]}; 
                LED_Temp_Working<=~LED_Temp_Working; 
                fsmTemp<=0;
            end
    default:
        begin fsmTemp<=0; end
    endcase
end
assign oLED2=LED_Temp_Working; 

/* -------- UART Transmit Module -------- */
/* generate 1MHz Clock, //48MHz/1MHz=48. */
/* generate 4MHz Clock, //48MHz/4MHz=12. */
/* generate 8MHz Clock, //48MHz/8MHz=6. */
reg tx_en;
reg [7:0] tx_data;
wire tx_done;
ZUART_Tx #(.Freq_divider(12)) uart_u1
(
	.iClk(clk_48MHz_Global),
	.iRst_N(rst_n),
	.iData(tx_data),
	
	/* pull down iEn to start transmition until pulse done oDone was issued. */
	.iEn(tx_en),
	.oDone(tx_done),
	.oTxD(oData_TxD)
);

reg [7:0] fsmUART;
reg [31:0] LED_UART_Working;
always @(posedge clk_48MHz_Global or negedge rst_n) 
if(!rst_n) begin 
	fsmUART<=0; tx_en<=0; LED_UART_Working<=0; oTx_FPS<=0; 
end
else begin
    case(fsmUART)
	0: /* waiting for trigger */
        begin fsmUART<=(adc_valid)?(fsmUART+1):(fsmUART); end

	1: /* transmit fixed head byte 0x55 */
        if(tx_done) begin tx_en<=0; fsmUART<=fsmUART+1; end
		else begin tx_en<=1; tx_data<=8'h55; end
			
    2: /* transmit the high 8 bits of ADC */
        if(tx_done) begin tx_en<=0; fsmUART<=fsmUART+1; end
		else begin tx_en<=1; tx_data<=captured_data[15:8]/*8'h19*/; end
			
    3: /* transmit the low 8 bits of ADC */
	    if(tx_done) begin tx_en<=0; fsmUART<=fsmUART+1; end
		else begin tx_en<=1; tx_data<=captured_data[7:0]/*8'h87*/; end
			
    4: /* transmit Temperature byte. -127 degree celsius ~ +128 degree celsius. */
		if(tx_done) begin tx_en<=0; fsmUART<=fsmUART+1; end
		else begin tx_en<=1; tx_data<=temp_Latest/*8'h09*/; end

    5: /* addition clock period */
		begin 
			LED_UART_Working<=(LED_UART_Working==32'd1000)?(0):(LED_UART_Working+1); 
			oTx_FPS<=~oTx_FPS;
            fsmUART<=0; 
		end
    default:
            begin fsmUART<=0; end
    endcase
end
assign oLED1=(LED_ADC_Working>32'd300)?(1):(0);
endmodule
