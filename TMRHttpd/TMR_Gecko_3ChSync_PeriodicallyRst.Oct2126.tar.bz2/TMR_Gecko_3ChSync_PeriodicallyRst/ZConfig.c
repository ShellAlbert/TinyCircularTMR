#include "ZConfig.h"
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#define MAX_LINE_LENGTH (256)


//line format.
// Y=k*(X+b1)+b2,k1=xx.xxx,b11=xx.xxx,b12=xx.xxx,k2=xx.xxx,b21=xx.xxx,b22=xx.xxx,k3=xx.xxx,b31=xx.xxx,b32=xx.xxx.

#define PREFIX_COEFFICIENT	"Y=k*(X+b1)+b2"

ConfigSet_t confSet;
/* load config file */
int ZConfig_Load()
{
	char buffer[MAX_LINE_LENGTH];
	FILE *fp=fopen(CONFIG_FILE, "r");
	if(NULL==fp)
	{
		fprintf(stderr,"<error>: failed to open %s,%s.\n",CONFIG_FILE, strerror(errno));
		confSet.k1_coefficient=1.0f; /* Phase A */
		confSet.b11_offset=0.0f;
		confSet.b12_offset=0.0f;

		confSet.k2_coefficient=1.0f; /* Phase B */
		confSet.b21_offset=0.0f;
		confSet.b22_offset=0.0f;

		confSet.k3_coefficient=1.0f; /* Phase C */
		confSet.b31_offset=0.0f;
		confSet.b32_offset=0.0f;
		fprintf(stdout,"<warning>: default parameters will be used.\n");
		fprintf(stdout,"<info>: Phase A, k=%.3f, b1=%.3f, b2=%.3f\n",confSet.k1_coefficient,confSet.b11_offset,confSet.b12_offset);
		fprintf(stdout,"<info>: Phase B, k=%.3f, b1=%.3f, b2=%.3f\n",confSet.k2_coefficient,confSet.b21_offset,confSet.b22_offset);
		fprintf(stdout,"<info>: Phase C, k=%.3f, b1=%.3f, b2=%.3f\n",confSet.k3_coefficient,confSet.b31_offset,confSet.b32_offset);
		return -1;
	}

	while(fgets(buffer,sizeof(buffer),fp)!=NULL)
	{
		int len=strlen(buffer);
		if(len>0 && buffer[len-1]=='\n')
		{
			//printf("%s\n",buffer);
			if(!strncmp(buffer,PREFIX_COEFFICIENT,strlen(PREFIX_COEFFICIENT)))
			{
				int ret=sscanf(buffer,"Y=k*(X+b1)+b2:k1=%f,b11=%f,b12=%f,k2=%f,b21=%f,b22=%f,k3=%f,b31=%f,b32=%f.\n", ///<
						&confSet.k1_coefficient,&confSet.b11_offset,&confSet.b12_offset, ///
						&confSet.k2_coefficient,&confSet.b21_offset,&confSet.b22_offset, ///
						&confSet.k3_coefficient,&confSet.b31_offset,&confSet.b32_offset);
				//printf("ret=%d\n",ret);
				if(9==ret)
				{
					fprintf(stdout,"<info>: Read config file Y=k*(X+b1)+b2.\n");
					fprintf(stdout,"<info>: Phase A, k=%.3f, b1=%.3f, b2=%.3f\n",confSet.k1_coefficient,confSet.b11_offset,confSet.b12_offset);
					fprintf(stdout,"<info>: Phase B, k=%.3f, b1=%.3f, b2=%.3f\n",confSet.k2_coefficient,confSet.b21_offset,confSet.b22_offset);
					fprintf(stdout,"<info>: Phase C, k=%.3f, b1=%.3f, b2=%.3f\n",confSet.k3_coefficient,confSet.b31_offset,confSet.b32_offset);
				}else{
					fprintf(stderr,"<error>: format input config file failed,%s.\n",strerror(errno));
				}
			}
		}
	}
	fclose(fp);
	return 0;
}

/* flush new data to config file */
int ZConfig_Flush()
{
	char buffer[MAX_LINE_LENGTH];
	FILE *fp=fopen(CONFIG_FILE, "w");
	if(NULL==fp)
	{
		fprintf(stderr,"<error>: failed to open %s,%s.\n",CONFIG_FILE, strerror(errno));
		return -1;
	}

	snprintf(buffer,sizeof(buffer),"%s:k1=%f,b11=%f,b12=%f,k2=%f,b21=%f,b22=%f,k3=%f,b31=%f,b32=%f.\n", ///<
			PREFIX_COEFFICIENT, ///<
			confSet.k1_coefficient,confSet.b11_offset,confSet.b12_offset, ///
			confSet.k2_coefficient,confSet.b21_offset,confSet.b22_offset, ///
			confSet.k3_coefficient,confSet.b31_offset,confSet.b32_offset);

	fwrite(buffer,strlen(buffer),1,fp);
	fclose(fp);
}

