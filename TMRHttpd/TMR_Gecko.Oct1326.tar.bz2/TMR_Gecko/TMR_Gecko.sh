#!/bin/bash

FILE_captured="/tmp/TMR_Captured.pid"
FILE_httpd="/tmp/TMR_Httpd.pid"

function launch_TMR_Captured()
{
	/home/TMR/TMR_Gecko/TMR_Captured.bin >/dev/null 2>&1 &
	newPID=$!
	if [ $? -eq 0 ]; then
		echo "TMR_Captured was launched with PID($newPID)."
	else
		echo "Failed to launch TMR_Capture."
	fi
}
function launch_TMR_Httpd()
{
	/home/TMR/TMR_Gecko/TMR_Httpd.bin >/dev/null 2>&1 &
	newPID=$!
	if [ $? -eq 0 ]; then
		echo "TMR_Httpd was launched with PID($newPID)."
	else
		echo "Failed to launch TMR_Httpd."
	fi
}


# the super loop here.
while true
do
	# read the latest pid file.
	PID_captured=$(cat $FILE_captured)
	PID_httpd=$(cat $FILE_httpd)

	# check whether the pid file exists or not.
	if [ -e $FILE_captured ]; then
		if kill -0 $PID_captured 2>/dev/null; then
			echo "TMR_Captured($PID_captured) is alive."
		else
			echo "TMR_Captured($PID_captured) is dead, re-launch it."
			launch_TMR_Captured
		fi
	else
		echo "TMR_Captured never runs, launch it."
		launch_TMR_Captured
	fi

	# check whether the pid file exists or not.
	if [ -e $FILE_httpd ]; then
		if kill -0 $PID_httpd 2>/dev/null; then
			echo "TMR_Httpd($PID_httpd) is alive."
		else
			echo "TMR_Httpd($PID_httpd) is dead, re-launch it."
			launch_TMR_Httpd
		fi
	else
		echo "TMR_Httpd never runs, launch it."
		launch_TMR_Httpd
	fi

	#check every 5 seconds.
	date
	echo ""
	sleep 5
done
