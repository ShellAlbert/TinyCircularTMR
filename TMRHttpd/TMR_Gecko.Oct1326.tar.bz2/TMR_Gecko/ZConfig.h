#ifndef _ZCONFIG_H__
#define _ZCONFIG_H__

/* default configure file name */
#define CONFIG_FILE "TMR.conf"

typedef struct{
	/* Y=kX+b */
	float k_coefficient;
	float b_offset;

}ConfigSet_t;

extern ConfigSet_t confSet;

/* load config file */
extern int ZConfig_Load();

/* flush new data to config file */
extern int ZConfig_Flush();

#endif //_ZCONFIG_H__