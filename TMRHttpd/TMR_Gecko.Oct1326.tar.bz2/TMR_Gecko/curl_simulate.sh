#!/bin/bash
count=0
while true
do
	curl  "http://localhost:8080/TMR/Phase_Curve?Ph=A&Type=RawData"
	sleep 1
	curl  "http://localhost:8080/TMR/Phase_Curve?Ph=A&Type=RawData_CSV"
	sleep 1
	curl  "http://localhost:8080/TMR/Phase_Curve?Ph=A&Type=Image"
	sleep 1
	((count++))
	echo "repeat time:" $count
done

