#include "ZConfig.h"
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#define MAX_LINE_LENGTH (256)

ConfigSet_t confSet;

/* load config file */
int ZConfig_Load()
{
	char buffer[MAX_LINE_LENGTH];
	FILE *fp=fopen(CONFIG_FILE, "r");
	if(NULL==fp)
	{
		fprintf(stderr,"<error>: failed to open %s,%s.\n",CONFIG_FILE, strerror(errno));
		return -1;
	}

	while(fgets(buffer,sizeof(buffer),fp)!=NULL)
	{
		int len=strlen(buffer);
		if(len>0 && buffer[len-1]=='\n')
		{
			//printf("%s\n",buffer);
			if(!strncmp(buffer,"Y=kX+b",6))
			{
				int ret=sscanf(buffer,"Y=kX+b,k=%f,b=%f.\n",&confSet.k_coefficient,&confSet.b_offset);
				//printf("ret=%d\n",ret);
				if(2==ret)
				{
					fprintf(stdout,"<info>: Read config file Y=(%.2f)*X+(%.2f).\n",confSet.k_coefficient,confSet.b_offset);
				}else{
					fprintf(stderr,"<error>: format input config file failed,%s.\n",strerror(errno));
				}
			}
		}
	}

	fclose(fp);
	return 0;
}

/* flush new data to config file */
int ZConfig_Flush()
{
	char buffer[MAX_LINE_LENGTH];
	FILE *fp=fopen(CONFIG_FILE, "w");
	if(NULL==fp)
	{
		fprintf(stderr,"<error>: failed to open %s,%s.\n",CONFIG_FILE, strerror(errno));
		return -1;
	}

	snprintf(buffer,sizeof(buffer),"Y=kX+b,k=%.2f,b=%.2f.\n",confSet.k_coefficient,confSet.b_offset);
	fwrite(buffer,strlen(buffer),1,fp);
	fclose(fp);
}

