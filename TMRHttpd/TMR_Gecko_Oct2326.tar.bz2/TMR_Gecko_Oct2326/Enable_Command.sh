TMR@localhost:~/TMR_Gecko_Oct2326> sudo systemctl enable TMR_Httpd.service 
[sudo] password for TMR: 
Created symlink '/etc/systemd/system/multi-user.target.wants/TMR_Httpd.service' → '/etc/systemd/system/TMR_Httpd.service'.
TMR@localhost:~/TMR_Gecko_Oct2326> sudo systemctl enable TMR_Captured.service 
Created symlink '/etc/systemd/system/multi-user.target.wants/TMR_Captured.service' → '/etc/systemd/system/TMR_Captured.service'.
TMR@localhost:~/TMR_Gecko_Oct2326> 

