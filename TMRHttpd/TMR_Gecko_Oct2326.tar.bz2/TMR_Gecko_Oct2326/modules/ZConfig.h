#ifndef _ZCONFIG_H__
#define _ZCONFIG_H__

/* default configure file name */
#define CONFIG_FILE "/etc/TMR/TMR.conf"

/* current linear correction coefficient */
/* the formula is Y=k*(X+b1)+b2, normally b2=0. */
/* Y=k*(X+b1)+b2 */
typedef struct{
	/* Phase A */
	float k1_coefficient;
	float b11_offset;
	float b12_offset;

	/* Phase B */
	float k2_coefficient;
	float b21_offset;
	float b22_offset;

	/* Phase C */
	float k3_coefficient;
	float b31_offset;
	float b32_offset;

	/* write http file interval. */
	int wrHttpFileInterval;
	int filterEn;
	int filterWinSize;
	int syncEn; 
	int syncInterval;
	int httpDataSize;
	int logEn;
	int correctionEn;
}ConfigSet_t;

extern ConfigSet_t confSet;

/* load config file */
extern int ZConfig_Load();

/* flush new data to config file */
extern int ZConfig_Flush();

#endif //_ZCONFIG_H__