#include "ZConfig.h"
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#define MAX_LINE_LENGTH (256)


//line format.
// Y=k*(X+b1)+b2,k1=xx.xxx,b11=xx.xxx,b12=xx.xxx,k2=xx.xxx,b21=xx.xxx,b22=xx.xxx,k3=xx.xxx,b31=xx.xxx,b32=xx.xxx.

#define PREFIX_COEFFICIENT	"Y=k*(X+b1)+b2"

// wrHttpFile=15&filter=on&winSize=32&syncEn=on&syncInterval=10&httpDataSize=800&wrLog=on&applyCorrection=on
#define PREFIX_DEVPARAM "DevParam"

ConfigSet_t confSet;
/* load config file */
int ZConfig_Load()
{
	char buffer[MAX_LINE_LENGTH];
	FILE *fp=fopen(CONFIG_FILE, "r");
	if(NULL==fp)
	{
		fprintf(stderr,"<error>: failed to open %s,%s.\n",CONFIG_FILE, strerror(errno));
		confSet.k1_coefficient=1.0f; /* Phase A */
		confSet.b11_offset=0.0f;
		confSet.b12_offset=0.0f;

		confSet.k2_coefficient=1.0f; /* Phase B */
		confSet.b21_offset=0.0f;
		confSet.b22_offset=0.0f;

		confSet.k3_coefficient=1.0f; /* Phase C */
		confSet.b31_offset=0.0f;
		confSet.b32_offset=0.0f;

		confSet.wrHttpFileInterval=15; /* 15 second. */
		confSet.filterEn=1; /* slide window smooth filter on. */
		confSet.filterWinSize=32; 
		confSet.syncEn=1; 
		confSet.syncInterval=10; 
		confSet.httpDataSize=800; 
		confSet.logEn=1;
		confSet.correctionEn=1;

		fprintf(stdout,"<warning>: default parameters will be used.\n");
		fprintf(stdout,"<info>: Phase A, k=%.6f, b1=%.6f, b2=%.6f\n",confSet.k1_coefficient,confSet.b11_offset,confSet.b12_offset);
		fprintf(stdout,"<info>: Phase B, k=%.6f, b1=%.6f, b2=%.6f\n",confSet.k2_coefficient,confSet.b21_offset,confSet.b22_offset);
		fprintf(stdout,"<info>: Phase C, k=%.6f, b1=%.6f, b2=%.6f\n",confSet.k3_coefficient,confSet.b31_offset,confSet.b32_offset);
		fprintf(stdout,"<info>: wrHttpFileInterval=%d, httpDataSize=%d\n",confSet.wrHttpFileInterval,confSet.httpDataSize);
		fprintf(stdout,"<info>: Slide Window Smooth Filter=%d, Window Size=%d\n",confSet.filterEn,confSet.filterWinSize);
		fprintf(stdout,"<info>: Phase Compensation Periodically=%d, Every %d Frames.\n",confSet.syncEn,confSet.syncInterval);
		fprintf(stdout,"<info>: Write Log File=%d, Applying Correction=%d\n",confSet.logEn,confSet.correctionEn);
		return -1;
	}

	while(fgets(buffer,sizeof(buffer),fp)!=NULL)
	{
		int len=strlen(buffer);
		if(len>0 && buffer[len-1]=='\n')
		{
			//printf("%s\n",buffer);
			if(!strncmp(buffer,PREFIX_COEFFICIENT,strlen(PREFIX_COEFFICIENT)))
			{
				int ret=sscanf(buffer,"Y=k*(X+b1)+b2:k1=%f,b11=%f,b12=%f,k2=%f,b21=%f,b22=%f,k3=%f,b31=%f,b32=%f\n", ///<
						&confSet.k1_coefficient,&confSet.b11_offset,&confSet.b12_offset, ///
						&confSet.k2_coefficient,&confSet.b21_offset,&confSet.b22_offset, ///
						&confSet.k3_coefficient,&confSet.b31_offset,&confSet.b32_offset);
				//printf("ret=%d\n",ret);
				if(9==ret)
				{
					fprintf(stdout,"<info>: Read config file Y=k*(X+b1)+b2.\n");
					fprintf(stdout,"<info>: Phase A, k=%.6f, b1=%.6f, b2=%.6f\n",confSet.k1_coefficient,confSet.b11_offset,confSet.b12_offset);
					fprintf(stdout,"<info>: Phase B, k=%.6f, b1=%.6f, b2=%.6f\n",confSet.k2_coefficient,confSet.b21_offset,confSet.b22_offset);
					fprintf(stdout,"<info>: Phase C, k=%.6f, b1=%.6f, b2=%.6f\n",confSet.k3_coefficient,confSet.b31_offset,confSet.b32_offset);
				}else{
					fprintf(stderr,"<error>: format input config file failed,%s.\n",strerror(errno));
				}
			}

			if(!strncmp(buffer,PREFIX_DEVPARAM,strlen(PREFIX_DEVPARAM)))
			{
				int ret=sscanf(buffer,"DevParam:wrHttpFile=%d&filter=%d&winSize=%d&syncEn=%d&syncInterval=%d&httpDataSize=%d&wrLog=%d&applyCorrection=%d\n", ///<
						&confSet.wrHttpFileInterval,&confSet.filterEn,&confSet.filterWinSize, ///
						&confSet.syncEn,&confSet.syncInterval,&confSet.httpDataSize, ///
						&confSet.logEn,&confSet.correctionEn);
				//printf("ret=%d\n",ret);
				if(8==ret)
				{
					fprintf(stdout,"<info>: wrHttpFileInterval=%d, httpDataSize=%d\n",confSet.wrHttpFileInterval,confSet.httpDataSize);
					fprintf(stdout,"<info>: Slide Window Smooth Filter=%d, Window Size=%d\n",confSet.filterEn,confSet.filterWinSize);
					fprintf(stdout,"<info>: Phase Compensation Periodically=%d, Every %d Frames.\n",confSet.syncEn,confSet.syncInterval);
					fprintf(stdout,"<info>: Write Log File=%d, Applying Correction=%d\n",confSet.logEn,confSet.correctionEn);
				}else{
					fprintf(stderr,"<error>: format input config file failed,%s.\n",strerror(errno));
				}
			}
		}
	}
	fclose(fp);
	return 0;
}

/* flush new data to config file */
int ZConfig_Flush()
{
	char buffer[MAX_LINE_LENGTH];
	FILE *fp=fopen(CONFIG_FILE, "w");
	if(NULL==fp)
	{
		fprintf(stderr,"<error>: failed to open %s,%s.\n",CONFIG_FILE, strerror(errno));
		return -1;
	}

	snprintf(buffer,sizeof(buffer),"%s:k1=%.6f,b11=%.6f,b12=%.6f,k2=%.6f,b21=%.6f,b22=%.6f,k3=%.6f,b31=%.6f,b32=%.6f\n", ///<
			PREFIX_COEFFICIENT, ///<
			confSet.k1_coefficient,confSet.b11_offset,confSet.b12_offset, ///
			confSet.k2_coefficient,confSet.b21_offset,confSet.b22_offset, ///
			confSet.k3_coefficient,confSet.b31_offset,confSet.b32_offset);

	fwrite(buffer,strlen(buffer),1,fp);

	snprintf(buffer,sizeof(buffer),"%s:wrHttpFile=%d&filter=%d&winSize=%d&syncEn=%d&syncInterval=%d&httpDataSize=%d&wrLog=%d&applyCorrection=%d\n", ///<
			PREFIX_DEVPARAM, ///<
			confSet.wrHttpFileInterval,confSet.filterEn,confSet.filterWinSize, ///
			confSet.syncEn,confSet.syncInterval,confSet.httpDataSize, ///
			confSet.logEn,confSet.correctionEn);

	fwrite(buffer,strlen(buffer),1,fp);

	fclose(fp);
}

