
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define _POSIX_C_SOURCE 200809L
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>


//#define M_PI 3.415926

/* TMR Module Sample Frequency Fs=10kHz */
/* signal frequency Fd=50Hz*/
/* Fs/Fd=10kHz/50Hz=200 samples */
#define N (200*4) //display 2 AC periods.

struct point {
	double x; // the x position in the graph.
	double y; // the y position in the graph.
};
volatile unsigned char g_Exit=0;
volatile unsigned char g_ResetFIFO=0;

typedef struct{
	char *device_fifo;
	FILE *fp;
	struct point data[N];
}TMRDevice_t;

/* signal handler */
void signal_handler(int signo) {
	if (signo == SIGINT || signo == SIGKILL) {
		printf("Caught SIGINT, prepare to exit...\n");
		g_Exit=1; 
	}else if(signo == SIGUSR1){ //TMR_Httpd uses SIG_USR1 to notify me to reload confg file.
		fprintf(stdout,"<warning>: notified by SIGUSR1 to reset FIFO for asychronization.\n");
		g_ResetFIFO=1;
	}
}

int main(void)
{
	TMRDevice_t dev[3]={
		{.device_fifo="/tmp/TMR_Phase_A.fifo",.fp=NULL,.data=0,},
		{.device_fifo="/tmp/TMR_Phase_B.fifo",.fp=NULL,.data=0,},
		{.device_fifo="/tmp/TMR_Phase_C.fifo",.fp=NULL,.data=0,}};

	struct point a[N], b[N], c[N];

	struct timespec ts;
	ts.tv_sec = 0;
	ts.tv_nsec = 16 * 1000 * 1000; // 16 毫秒 = 16,000,000 纳秒

	/* write my pid to file. */
	FILE *fp_pid = fopen("/tmp/TMR_Plot.pid", "w");
	if (fp_pid) {
		pid_t mypid = getpid();
		fprintf(fp_pid, "%d\n", mypid);
		fclose(fp_pid);
		fp_pid = NULL;
	}

	/* install signal handler */
	signal(SIGINT,signal_handler);
	signal(SIGKILL,signal_handler);
	signal(SIGUSR1,signal_handler);
	// for a named FIFO, when reader exits, it emits SIG_PIPE will cause writer to
	// exit. here we ignore SIGPIPE.
	signal(SIGPIPE, SIG_IGN);

	/* call gnuplot. */
	FILE *gp = popen("gnuplot", "w");
	if (!gp) {
		perror("popen");
		return 1;
	}

	setvbuf(gp, NULL, _IOFBF, 1 << 20);
	//"set terminal x11 noraise size 1000,500\n"
	//"set terminal qt noraise size 1000,500\n"
	fprintf(gp,
			"set terminal qt noraise size 1000,500\n"
			"set title '3-Phases Current Monitoring Curve' font 'Arial,20' \n"
			"set xlabel 'Sample/Count'\n"
			"set ylabel 'Value/Current'\n"
			"set grid\n"
			"set xrange [0:%d]\n"
			"set yrange [-1000:1000]\n"
			"set key top left\n",
			N - 1);

Reset_FIFO: /* reset workflow here. */
	g_ResetFIFO=0; 
	fprintf(stdout,"<warning>: reset periodically to prevent the difference in sample frequency.\n");

	/* delete the fifo to clear previous remained bytes to prevent asynchronous. */
	for(int i=0;i<3;i++)
	{
		int rc=unlink(dev[i].device_fifo);
		if(!rc){
			fprintf(stdout,"<info>: %s deleted.\n",dev[i].device_fifo);
		}else{
			fprintf(stdout,"<warning>: %s not found.\n",dev[i].device_fifo);
		}
	}

	/* create fifo again. */
	for(int i=0;i<3;i++)
	{
		if (mkfifo(dev[i].device_fifo, 0666)==-1) {
			if (errno == EEXIST) {
				fprintf(stdout,"<warning>: FIFO %s already exists.\n",dev[i].device_fifo);
			}else{
				fprintf(stderr,"<error>: mkfifo %s failed:%s.\n",dev[i].device_fifo, strerror(errno));
			}
		}else{
			fprintf(stdout,"<info>: FIFO %s created successfully.\n",dev[i].device_fifo);
		}
	}

	/* we use read+write mode to open the fifo to prevent blocking. */
	/* TMR_Plot only reads, TMR_Capture only writes. */
	for(int i=0;i<3;i++)
	{	/* Open the FIFO in read-write mode ("r+"), this will not block, even if no other process has opened the FIFO. */
		if(NULL==(dev[i].fp=fopen(dev[i].device_fifo,"r+")))
		{
			fprintf(stderr,"<error>: failed to open /tmp/TMR_Phase_A/B/C.fifo file,%s.\n",strerror(errno));
			fprintf(stderr,"<error>: highly recommend to call mkfifo to create them first.\n");
			fprintf(stderr,"<error>: MUST LAUNCH TMR_Plot.bin first to prevent asynchronous in 3 phase curves.\n");
			return -1;
		}else{
			fprintf(stdout,"<info>: FIFO %s was opened for reading only.\n",dev[i].device_fifo);
		}
	}

	/* set non-blocking mode. */
	for(int i=0;i<3;i++)
	{
		int fd=fileno(dev[i].fp);
		if(fd>0)
		{
			int flags=fcntl(fd,F_GETFL,0);
			if(flags<0)
			{
				perror("fcntl(F_GETFL)");
			}else{
				if(fcntl(fd,F_SETFL,flags|O_NONBLOCK)<0)
				{
					perror("fcntl(F_SETFL)");
				}else{
					fprintf(stdout,"<info>: %s set non-block mode successfully.\n",dev[i].device_fifo);
				}
			}
		}
	}

	fprintf(stdout,"<info>: super loop started.\n");
	/* the super loop entrance */
	while (!g_Exit && !g_ResetFIFO) {
		for(int i=0; i<N;i++) /* retrieve one complete frame */
		{
			for(int j=0;j<3;j++) /* process 3 channels independently. */
			{
				while(!g_Exit && !g_ResetFIFO){ /* non-blocking mode. */
					float phase_value;
					int bytes_read=fread(&phase_value,sizeof(phase_value),1,dev[j].fp);
					if(bytes_read>0)
					{
						dev[j].data[i].x=i;
						dev[j].data[i].y=phase_value;
						break;
					}else{
						if(feof(dev[j].fp))
						{
							fprintf(stdout,"<error>: end of file.\n");
							break;
						}else if(feof(dev[j].fp))
						{
							if(errno==EAGAIN || errno==EWOULDBLOCK)
							{
								usleep(1000);
								continue;
							}else{
								perror("fread() error");
								break;
							}
						}else{
							//fprintf(stdout,"<warning>: non-blocking mode, try again.\n");
						}
					}
				}
			}
		}

		/* with lines, with linespoints */
		/* first double is x axis. */
		/* second double is y axis. */
		fprintf(gp,
				"plot '-' binary record=%d format='%%double%%double' using 1:2 with lines lw 1.5 title 'PhaseA', "
				"     '-' binary record=%d format='%%double%%double' using 1:2 with lines lw 1.5 title 'PhaseB', "
				"     '-' binary record=%d format='%%double%%double' using 1:2 with lines lw 1.5 title 'PhaseC'\n",
				N, N, N);

		fwrite(dev[0].data, sizeof(dev[0].data[0]), N, gp);
		fwrite(dev[1].data, sizeof(dev[1].data[0]), N, gp);
		fwrite(dev[2].data, sizeof(dev[2].data[0]), N, gp);
		fflush(gp);

		//usleep(16 * 1000);  /* ~60 Hz cap; drop this if you want max throughput */
		//nanosleep(&ts, NULL);

		/* dump one frame to local file */
		// FILE *fp_dump=fopen("a.csv","w");
		// if(fp_dump)
		// {
		// 	for(int i=0;i<N;i++)
		// 	{
		// 		char buffer[128];
		// 		snprintf(buffer,sizeof(buffer),"%.2f\n",a[i].y);
		// 		fwrite(buffer,strlen(buffer),1,fp_dump);
		// 	}
		// 	fflush(fp_dump);
		// 	fclose(fp_dump);
		// }
		// printf("dump done!\n");
		// exit(0);
	}

	/* check signal. */
	if(g_ResetFIFO)
	{
		goto Reset_FIFO;
	}
	pclose(gp);
	gp=NULL;
	fprintf(stdout,"<info>: TMR_Plot quit normally.\n");
	return 0;
}
