#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include <signal.h>

#define M_PI 3.415926
/* TMR Module Sample Frequency Fs=10kHz */
/* signal frequency Fd=50Hz*/
/* Fs/Fd=10kHz/50Hz=200 samples */
#define N (200*4) //display 2 AC periods.

struct point {
	double x; // the x position in the graph.
	double y; // the y position in the graph.
};
volatile unsigned char g_Exit=0;

/* signal handler */
void signal_handler(int signo) {
	if (signo == SIGINT || signo == SIGKILL) {
		printf("Caught SIGINT, prepare to exit...\n");
		g_Exit=1; 
	}
}

int main(void)
{
	struct point a[N], b[N], c[N];

	struct timespec ts;
	ts.tv_sec = 0;
	ts.tv_nsec = 16 * 1000 * 1000; // 16 毫秒 = 16,000,000 纳秒

	FILE *gp = popen("gnuplot", "w");
	if (!gp) {
		perror("popen");
		return 1;
	}

	setvbuf(gp, NULL, _IOFBF, 1 << 20);
	//"set terminal qt noraise size 1000,500\n"
	fprintf(gp,
			"set terminal x11 noraise size 1000,500\n"
			"set title '3-Phases Current Monitoring Curve' font 'Arial,20' \n"
			"set xlabel 'Sample/Count'\n"
			"set ylabel 'Value/Current'\n"
			"set grid\n"
			"set xrange [0:%d]\n"
			"set yrange [-1000:1000]\n"
			"set key top left\n",
			N - 1);


	FILE *fp1, *fp2, *fp3;
	fp1=fopen("/tmp/TMR_Phase_A.fifo","r");
	fp2=fopen("/tmp/TMR_Phase_B.fifo","r");
	fp3=fopen("/tmp/TMR_Phase_C.fifo","r");
	if(fp1==NULL || fp2==NULL || fp3==NULL)
	{
		printf("failed to open fifo file\n");
		return -1;
	}

	/* install signal handler */
	signal(SIGINT,signal_handler);
	signal(SIGKILL,signal_handler);

	/* the super loop entrance */
	while (!g_Exit) {
		/* retrieve one complete frame */
		for(int i=0; i<N;i++)
		{
			float phase_value;

			/* read data from FIFO file */
			if(fread(&phase_value, sizeof(float), 1, fp1) !=1){
				printf("read failed,%s\n",strerror(errno));
			} else {
				//printf("Channel %d, get new value: %.2f\n", i, phase_value);
				a[i].x=i;
				a[i].y=phase_value;
			}

			if (fread(&phase_value, sizeof(float), 1, fp2) != 1) {
				printf("read failed,%s\n",strerror(errno));
			} else {
				//printf("Channel %d, get new value: %.2f\n", i, phase_value);
				b[i].x=i;
				b[i].y=phase_value;
			}

			if (fread(&phase_value, sizeof(float), 1, fp3) != 1) {
				printf("read failed,%s\n",strerror(errno));
			} else {
				//printf("Channel %d, get new value: %.2f\n", i, phase_value);
				c[i].x=i;
				c[i].y=phase_value;
			}
		}


		fprintf(gp,
				"plot '-' binary record=%d format='%%double%%double' using 1:2 with lines lw 1.5 title 'PhaseA', "
				"     '-' binary record=%d format='%%double%%double' using 1:2 with lines lw 1.5 title 'PhaseB', "
				"     '-' binary record=%d format='%%double%%double' using 1:2 with lines lw 1.5 title 'PhaseC'\n",
				N, N, N);

		fwrite(a, sizeof(a[0]), N, gp);
		fwrite(b, sizeof(b[0]), N, gp);
		fwrite(c, sizeof(c[0]), N, gp);
		fflush(gp);

		//usleep(16 * 1000);  /* ~60 Hz cap; drop this if you want max throughput */
		//nanosleep(&ts, NULL);

		/* dump one frame to local file */
		// FILE *fp_dump=fopen("a.csv","w");
		// if(fp_dump)
		// {
		// 	for(int i=0;i<N;i++)
		// 	{
		// 		char buffer[128];
		// 		snprintf(buffer,sizeof(buffer),"%.2f\n",a[i].y);
		// 		fwrite(buffer,strlen(buffer),1,fp_dump);
		// 	}
		// 	fflush(fp_dump);
		// 	fclose(fp_dump);
		// }
		// printf("dump done!\n");
		// exit(0);
	}

	pclose(gp);
	return 0;
}
