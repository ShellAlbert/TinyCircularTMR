/*
 * Real-time 3-curve gnuplot pipe — sliding x-window (scroll left).
 *
 *   gcc gnuplot_abc.c -o gnuplot_abc -lm
 *   ./gnuplot_abc
 *
 * If the plot only updates when you click/resize the window (common on
 * GNOME + Wayland + wxt), use one of:
 *   GDK_BACKEND=x11 ./gnuplot_abc
 *   or switch terminal to qt below (set term qt).
 *
 * Each frame: set xrange, plot 3x '-', pause 0, fflush.
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <error.h>
#include <errno.h>

//How many samples in one chart.
#define SAMPLES (256)
typedef struct {
    char *file_name;
    FILE *fp;
    double buf[SAMPLES];
    int pos;
} channel_t;

//Signal handler to exit.
volatile int g_Exit=0; 
void signal_handler(int signo)
{
    if(signo==SIGINT)
    {
        printf("Caught SIGINT...\n");
        g_Exit=1;
    }
}

static void push(channel_t *ch, double new_value)
{
    ch->buf[ch->pos] = new_value;
    //generate a ring buffer, adjust write position. 
    ch->pos = (ch->pos + 1) % SAMPLES;
}

static void send_series(FILE *gp, const channel_t *ch, long long n)
{
    long long x0 = (n > SAMPLES) ? (n - SAMPLES + 1) : 1;
    int count = (n > SAMPLES) ? SAMPLES : (int)n;
    int k;

    for (k = 0; k < count; k++) {
        int idx = (n > SAMPLES) ? (ch->pos + k) % SAMPLES : k;
        fprintf(gp, "%lld %f\n", x0 + k, ch->buf[idx]);
    }
    fprintf(gp, "e\n");
}

static int gp_ok(FILE *gp)
{
    return gp && !ferror(gp) && !feof(gp);
}

int main(void)
{
    FILE *gp;
    int i;
    channel_t channels[3]={
        {"/tmp/phase_a_plot.fifo",0},
        {"/tmp/phase_b_plot.fifo",0},
        {"/tmp/phase_c_plot.fifo",0}
    };
    long long n = 0;

    setenv("GDK_BACKEND", "x11", 0);

    //gp = popen("gnuplot -persist", "w");
    gp = popen("gnuplot", "w");
    if (!gp) {
        perror("gnuplot");
        return 1;
    }

    setvbuf(gp, NULL, _IONBF, 0);
    

    fprintf(gp,
        "set term qt noraise\n" //The plot is updated in the background. 
        "set title '3-Phases Current Monitoring Curve' font 'Arial,20' \n"
        "set xlabel 'Sample/Time'\n"
        "set ylabel 'Value/Current'\n"
        "set yrange [-10:10]\n"
        "unset autoscale\n"
        "set key top left\n"
        "set style line 1 lc rgb '#FF0000' lw 2\n"
        "set style line 2 lc rgb '#0000FF' lw 2\n"
        "set style line 3 lc rgb '#000000' lw 2\n");

    //install signal handler.
    signal(SIGINT,signal_handler);

    //open FIFO for reading.
    for(i=0;i<3;i++)
    {
        channels[i].fp=fopen(channels[i].file_name,"r");
        if(!channels[i].fp)
        {
            fprintf(stderr, "Error opening file %s %s.\n",channels[i].file_name, strerror(errno));
            return -1;
        }
    }

    while (!g_Exit) {

        //adjust xrange.
        fprintf(gp, "set xrange [%lld:%lld]\n",(n > SAMPLES) ? (n - SAMPLES + 1) : 1, n);
        fprintf(gp,
            "plot '-' title 'Phase A' with lines ls 1, "
            "     '-' title 'Phase B' with lines ls 2, "
            "     '-' title 'Phase C' with lines ls 3\n");

        //read data from FIFO.
        for(i=0;i<3;i++)
        {
            float phase_value;
            size_t byte_read=fread(&phase_value, sizeof(float),1, channels[i].fp);
            if(byte_read!=1)
            {
                if(feof(channels[i].fp))
                {
                    fprintf(stderr,"Channel %d, End of file reached %s\n",i,channels[i].file_name);
                }else{
                    perror("fread()");
                }
            }else{
                push(&channels[i], phase_value);
                send_series(gp,&channels[i],n);
                printf("Channel %d, get new value: %.2f\n", i, phase_value);
            }
        }
        n++;

        fprintf(gp, "pause 0\n");

        if (fflush(gp) != 0 || !gp_ok(gp))
            break;

        //usleep(20000);
        usleep(1000*50);
    }
    fprintf(gp,"exit\n");
    fflush(gp);
    pclose(gp);
    for(i=0;i<3;i++)
    {
        fclose(channels[i].fp);
        unlink(channels[i].file_name);
    }
    return 0;
}
